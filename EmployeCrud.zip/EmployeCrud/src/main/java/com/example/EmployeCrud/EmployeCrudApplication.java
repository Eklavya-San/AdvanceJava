package com.example.EmployeCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeCrudApplication.class, args);
	}

}
